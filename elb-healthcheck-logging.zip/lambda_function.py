import json
import boto3
from botocore.config import Config

def lambda_handler(event, context):
    
    config = Config(
        region_name = 'ap-southeast-2',
        signature_version = 'v4',
        retries = {
            'max_attempts': 10,
            'mode': 'standard'
        }
    )
    
    elbv2 = boto3.client('elbv2',config=config)
    
    answers = {}
    tg_target_count = [] 
    
    answers['tg'] = [{'tg_arn': 'arn:aws:elasticloadbalancing:ap-southeast-2:318360445202:targetgroup/IddAw-onosp-VZ82946B3FRZ/0247a1ab3ff68a9e', 'success_codes': '200', 'hc_timeout': 5}, {'tg_arn': 'arn:aws:elasticloadbalancing:ap-southeast-2:318360445202:targetgroup/ecs-dev-te-nginx-dynPort/c4032ff06a0277dc', 'success_codes': '200', 'hc_timeout': 5}, {'tg_arn': 'arn:aws:elasticloadbalancing:ap-southeast-2:318360445202:targetgroup/ecs-dev-te-test/14755286b2717e91', 'success_codes': '200', 'hc_timeout': 5}, {'tg_arn': 'arn:aws:elasticloadbalancing:ap-southeast-2:318360445202:targetgroup/ecs-dev-te-wiki-tool-fe/338981750bb42d49', 'success_codes': '200', 'hc_timeout': 5}, {'tg_arn': 'arn:aws:elasticloadbalancing:ap-southeast-2:318360445202:targetgroup/onos-alb-0-instance-tg-0/225950b0e96972dd', 'success_codes': '200', 'hc_timeout': 5}, {'tg_arn': 'arn:aws:elasticloadbalancing:ap-southeast-2:318360445202:targetgroup/onos-ip-as-target/8f95a994a32e9f59', 'success_codes': '200-399', 'hc_timeout': 5}, {'tg_arn': 'arn:aws:elasticloadbalancing:ap-southeast-2:318360445202:targetgroup/test-tg-tbd/985ad3ba5c298a3d', 'success_codes': '200', 'hc_timeout': 5}]
    
    for i in answers['tg']:
        if 'response' not in locals(): 
            response = elbv2.describe_target_health(TargetGroupArn=i['tg_arn'])
            tg_target_count.append(len(response['TargetHealthDescriptions']))
        #if there are multiple TGs or all TGs selected, keep appending the target health response
        else:
            temp = elbv2.describe_target_health(TargetGroupArn=i['tg_arn'])
            tg_target_count.append(len(temp['TargetHealthDescriptions']))
            response['TargetHealthDescriptions'] = response['TargetHealthDescriptions']+temp['TargetHealthDescriptions']

    log_client = boto3.client('logs', config=config)
    

    response = log_client.describe_log_streams(
        logGroupName='elb-healthcheck-logging',
        logStreamNamePrefix='app/onos-pub-vpc0-syd-alb-0/bcf7ee7beb876c4f',
        limit=10
    )
    
    ssm = boto3.client('ssm', config=config)
    sequenceToken = ssm.get_parameters(
        Names=['elb-hc-log-sequenceToken']
    )
    
    
    if(sequenceToken):
        print(sequenceToken['Parameters'][0]['Value'])
    else:
        print("sequenceToken doesn't exist")

    
    if (response): 
        put_log_events_response = log_client.put_log_events(
            logGroupName='elb-healthcheck-logging',
            logStreamName='app/onos-pub-vpc0-syd-alb-0/bcf7ee7beb876c4f',
            logEvents=[
                {
                    'timestamp': 1670373686000, #response['ResponseMetadata'].HTTPHeaders.date,
                    'message': 'elb logs'
                }
            ],
            sequenceToken=sequenceToken['Parameters'][0]['Value']
        )
    
        if(put_log_events_response['ResponseMetadata']['HTTPStatusCode'] == 200): 
            put_token = ssm.put_parameter(
                Name='elb-hc-log-sequenceToken',
                Value=put_log_events_response['nextSequenceToken'],
                Overwrite=True
        )
    
    
        print(put_log_events_response)
    else: 
        print("log group or log stream is not created")

#     print(response)
    
# def log_constructor(): 
    
#     time 
#     target 
#     port
#     health status 
#     failure reason 
#     json 
    

# def log_publisher(): 
    
    